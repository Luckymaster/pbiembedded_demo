// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

// Endpoint to get report config
export const reportUrl = 'http://localhost:8080/powerbi/getembedinfo';