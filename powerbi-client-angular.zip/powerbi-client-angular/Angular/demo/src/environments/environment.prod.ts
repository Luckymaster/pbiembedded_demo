// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

export const environment = {
  production: true
};
